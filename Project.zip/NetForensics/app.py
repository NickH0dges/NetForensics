import os
import sqlite3
import pyshark
from flask import Flask, request, send_file, jsonify, send_from_directory
from datetime import datetime
import csv
import asyncio

from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_bcrypt import Bcrypt

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, static_folder=os.path.join(BASE_DIR, "static"), static_url_path="")
app.secret_key = "supersecretkey"
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = False
app.config["SESSION_COOKIE_HTTPONLY"] = True

bcrypt = Bcrypt(app)
login_manager = LoginManager()
login_manager.init_app(app)

UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
REPORT_FOLDER = os.path.join(BASE_DIR, "reports")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(REPORT_FOLDER, exist_ok=True)
DB = os.path.join(BASE_DIR, "database.db")


def init_db():
    conn = sqlite3.connect(DB, timeout=30)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS packets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT, src_ip TEXT, dst_ip TEXT,
        protocol TEXT, src_port TEXT, dst_port TEXT, length INTEGER)""")
    c.execute("""CREATE TABLE IF NOT EXISTS logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        action TEXT, timestamp TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE, password TEXT, role TEXT)""")
    conn.commit()
    conn.close()

init_db()


class User(UserMixin):
    def __init__(self, id, username, role):
        self.id = id
        self.username = username
        self.role = role


@login_manager.user_loader
def load_user(user_id):
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE id=?", (user_id,))
    user = c.fetchone()
    conn.close()
    if user:
        return User(user[0], user[1], user[3])
    return None


@login_manager.unauthorized_handler
def unauthorized():
    return jsonify({"error": "Unauthorized"}), 401


def log_action(action):
    conn = sqlite3.connect(DB, timeout=30)
    c = conn.cursor()
    c.execute("INSERT INTO logs (action, timestamp) VALUES (?, ?)",
              (action, datetime.now().isoformat()))
    conn.commit()
    conn.close()


def clear_uploaded_pcaps():
    for filename in os.listdir(UPLOAD_FOLDER):
        file_path = os.path.join(UPLOAD_FOLDER, filename)
        try:
            if os.path.isfile(file_path):
                os.remove(file_path)
        except Exception as e:
            print(f"Error deleting {file_path}: {e}")


def find_tshark():
    """Find TShark executable on Windows or Linux."""
    import shutil
    # Check if tshark is already on PATH
    if shutil.which("tshark"):
        return shutil.which("tshark")
    # Common Windows install locations
    windows_paths = [
        r"C:\Program Files\Wireshark\tshark.exe",
        r"C:\Program Files (x86)\Wireshark\tshark.exe",
    ]
    for path in windows_paths:
        if os.path.exists(path):
            return path
    return None


def parse_pcap(filepath):
    """Parse a PCAP file and store packets in the database. Returns count of parsed packets."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    tshark_path = find_tshark()
    if not tshark_path:
        raise Exception("TShark not found. Please install Wireshark from https://www.wireshark.org/download.html")

    print(f"[PCAP] Using TShark at: {tshark_path}")

    cap = pyshark.FileCapture(
        filepath,
        keep_packets=False,
        use_json=True,
        include_raw=False,
        tshark_path=tshark_path
    )

    conn = sqlite3.connect(DB, timeout=30)
    c = conn.cursor()
    count = 0
    errors = 0

    first_error = None
    try:
        for packet in cap:
            try:
                # Timestamp
                try:
                    timestamp = packet.sniff_time.isoformat()
                except Exception:
                    timestamp = datetime.now().isoformat()

                # IPs
                try:
                    src_ip = packet.ip.src if hasattr(packet, "ip") else None
                    dst_ip = packet.ip.dst if hasattr(packet, "ip") else None
                except Exception:
                    src_ip = None
                    dst_ip = None

                # Protocol
                try:
                    protocol = packet.highest_layer
                except Exception:
                    protocol = "UNKNOWN"

                # Ports
                src_port = None
                dst_port = None
                try:
                    transport = getattr(packet, "transport_layer", None)
                    if transport:
                        src_port = packet[transport].srcport
                        dst_port = packet[transport].dstport
                except Exception:
                    pass

                # Length
                try:
                    length = int(packet.length)
                except Exception:
                    length = 0

                c.execute("""INSERT INTO packets
                    (timestamp, src_ip, dst_ip, protocol, src_port, dst_port, length)
                    VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (timestamp, src_ip, dst_ip, protocol, src_port, dst_port, length))
                count += 1

            except Exception as e:
                if first_error is None:
                    first_error = str(e)
                errors += 1
                continue
    finally:
        conn.commit()
        conn.close()
        try:
            cap.close()
        except Exception:
            pass

    print(f"[PCAP] Parsed {count} packets ({errors} skipped)")
    if first_error:
        print(f"[PCAP] First error was: {first_error}")
    return count


# ---------------------------
# Serve React Frontend
# ---------------------------
@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def serve_react(path):
    if path.startswith("api/"):
        return jsonify({"error": "Not found"}), 404
    static_file = os.path.join(app.static_folder, path)
    if path and os.path.exists(static_file):
        return send_from_directory(app.static_folder, path)
    return send_from_directory(app.static_folder, "index.html")


# ---------------------------
# API - AUTH
# ---------------------------
@app.route("/api/login", methods=["POST"])
def api_login():
    data = request.get_json()
    username = data.get("username", "")
    password = data.get("password", "")
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username=?", (username,))
    user = c.fetchone()
    conn.close()
    if user and bcrypt.check_password_hash(user[2], password):
        login_user(User(user[0], user[1], user[3]))
        log_action(f"Successful login: {username}")
        return jsonify({"success": True, "username": username, "role": user[3]})
    else:
        log_action(f"Failed login attempt: {username}")
        return jsonify({"success": False, "error": "Invalid credentials"}), 401


@app.route("/api/logout", methods=["POST"])
@login_required
def api_logout():
    username = current_user.username
    clear_uploaded_pcaps()
    log_action(f"User logged out: {username}")
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("DELETE FROM packets")
    conn.commit()
    conn.close()
    logout_user()
    return jsonify({"success": True})


@app.route("/api/me")
def api_me():
    if current_user.is_authenticated:
        return jsonify({"authenticated": True, "username": current_user.username, "role": current_user.role})
    return jsonify({"authenticated": False}), 401


# ---------------------------
# API - PCAP UPLOAD
# ---------------------------
@app.route("/api/upload", methods=["POST"])
@login_required
def api_upload():
    if "pcap" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["pcap"]

    if not file.filename.endswith((".pcap", ".pcapng", ".cap")):
        return jsonify({"error": "Invalid file format. Please upload a .pcap, .pcapng, or .cap file"}), 400

    # Validate magic bytes — checks actual file content, not just extension
    header = file.read(4)
    file.seek(0)
    PCAP_MAGIC = [
        b'\xd4\xc3\xb2\xa1',  # pcap little-endian
        b'\xa1\xb2\xc3\xd4',  # pcap big-endian
        b'\x0a\x0d\x0d\x0a',  # pcapng
    ]
    if header not in PCAP_MAGIC:
        return jsonify({"error": "File rejected: not a valid PCAP file. The content does not match any known PCAP format."}), 400

    filepath = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(filepath)
    log_action(f"{current_user.username} uploaded PCAP: {file.filename}")

    # Clear old session packets
    conn = sqlite3.connect(DB)
    conn.execute("DELETE FROM packets")
    conn.commit()
    conn.close()

    try:
        packet_count = parse_pcap(filepath)
    except Exception as e:
        return jsonify({"error": f"Failed to parse PCAP: {str(e)}. Make sure Wireshark/TShark is installed."}), 500

    if packet_count == 0:
        return jsonify({"error": "PCAP parsed but 0 packets were stored. This usually means TShark could not read the file. Check the server terminal for details."}), 400

    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT MIN(timestamp), MAX(timestamp) FROM packets")
    time_range = c.fetchone()
    c.execute("SELECT DISTINCT protocol FROM packets WHERE protocol IS NOT NULL")
    protocols = [row[0] for row in c.fetchall()]
    conn.close()

    return jsonify({
        "success": True,
        "filename": file.filename,
        "size": os.path.getsize(filepath),
        "packets": packet_count,
        "protocols": protocols,
        "start_time": time_range[0],
        "end_time": time_range[1],
    })


# ---------------------------
# API - DASHBOARD
# ---------------------------
@app.route("/api/dashboard")
@login_required
def api_dashboard():
    conn = sqlite3.connect(DB, timeout=30)
    c = conn.cursor()

    c.execute("SELECT COUNT(*) FROM packets")
    total_packets = c.fetchone()[0]

    c.execute("SELECT COUNT(DISTINCT src_ip) FROM packets WHERE src_ip IS NOT NULL")
    unique_ips = c.fetchone()[0]

    c.execute("SELECT SUM(length) FROM packets")
    total_bytes = c.fetchone()[0] or 0

    c.execute("""SELECT protocol, COUNT(*) as count FROM packets
        WHERE protocol IS NOT NULL
        GROUP BY protocol ORDER BY count DESC LIMIT 10""")
    protocol_dist = [{"name": r[0], "value": r[1]} for r in c.fetchall()]

    c.execute("""SELECT substr(timestamp, 1, 16) as minute,
        COUNT(*) as packets, SUM(length) as bytes
        FROM packets GROUP BY minute ORDER BY minute ASC LIMIT 50""")
    traffic_over_time = [{"time": r[0], "packets": r[1], "bytes": r[2]} for r in c.fetchall()]

    alerts = []
    c.execute("""SELECT src_ip, COUNT(*) FROM packets
        WHERE protocol='DNS' GROUP BY src_ip HAVING COUNT(*) > 50""")
    for row in c.fetchall():
        alerts.append({"type": "dns", "message": f"High DNS activity from {row[0]} ({row[1]} queries)"})

    c.execute("""SELECT src_ip, SUM(length) FROM packets
        GROUP BY src_ip HAVING SUM(length) > 1000000""")
    for row in c.fetchall():
        alerts.append({"type": "traffic", "message": f"Large data volume from {row[0]} ({row[1]:,} bytes)"})

    conn.close()

    return jsonify({
        "total_packets": total_packets,
        "unique_ips": unique_ips,
        "total_bytes": total_bytes,
        "protocol_distribution": protocol_dist,
        "traffic_over_time": traffic_over_time,
        "alerts": alerts,
        "alert_count": len(alerts),
    })


# ---------------------------
# API - PACKETS / TRAFFIC
# ---------------------------
@app.route("/api/packets")
@login_required
def api_packets():
    filter_ip = request.args.get("ip", "")
    filter_protocol = request.args.get("protocol", "")
    limit = int(request.args.get("limit", 200))

    conn = sqlite3.connect(DB, timeout=30)
    c = conn.cursor()

    query = "SELECT * FROM packets WHERE 1=1"
    params = []
    if filter_ip:
        query += " AND (src_ip=? OR dst_ip=?)"
        params.extend([filter_ip, filter_ip])
    if filter_protocol:
        query += " AND UPPER(protocol)=UPPER(?)"
        params.append(filter_protocol)
    query += f" LIMIT {limit}"

    c.execute(query, params)
    rows = c.fetchall()

    c.execute("""SELECT src_ip, COUNT(*) as packets, SUM(length) as bytes, protocol
        FROM packets WHERE src_ip IS NOT NULL
        GROUP BY src_ip ORDER BY packets DESC LIMIT 10""")
    talker_rows = c.fetchall()
    conn.close()

    packets = [{"id": r[0], "timestamp": r[1], "src_ip": r[2], "dst_ip": r[3],
                "protocol": r[4], "src_port": r[5], "dst_port": r[6], "length": r[7]}
               for r in rows]
    top_talkers = [{"ip": r[0], "packets": r[1], "bytes": r[2], "protocol": r[3]}
                   for r in talker_rows]

    return jsonify({"packets": packets, "top_talkers": top_talkers, "count": len(packets)})


# ---------------------------
# API - TIMELINE
# ---------------------------
@app.route("/api/timeline")
@login_required
def api_timeline():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("""SELECT timestamp, src_ip, dst_ip, protocol, length
        FROM packets ORDER BY timestamp ASC LIMIT 500""")
    rows = c.fetchall()
    conn.close()

    events = []
    for row in rows:
        timestamp, src_ip, dst_ip, protocol, length = row
        proto = (protocol or "").upper()
        if proto == "DNS":
            etype = "dns"
        elif proto in ("HTTP", "HTTPS", "HTTP2"):
            etype = "http"
        elif proto in ("TCP",):
            etype = "connection"
        else:
            etype = "data-transfer"

        severity = "warning" if length and length > 100000 else "info"
        description = (f"Large {proto} transfer ({length:,} bytes)"
                       if severity == "warning"
                       else f"{proto} packet — {src_ip or '?'} → {dst_ip or '?'} ({length} bytes)")

        events.append({
            "timestamp": timestamp,
            "type": etype,
            "source": src_ip or "unknown",
            "destination": dst_ip or "unknown",
            "protocol": proto,
            "description": description,
            "severity": severity,
            "length": length,
        })

    return jsonify({"events": events, "count": len(events)})


# ---------------------------
# API - ALERTS
# ---------------------------
@app.route("/api/alerts")
@login_required
def api_alerts():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    alerts = []

    c.execute("""SELECT src_ip, COUNT(*) FROM packets
        WHERE protocol='DNS' GROUP BY src_ip HAVING COUNT(*) > 50""")
    for row in c.fetchall():
        alerts.append({"type": "dns_flood", "severity": "warning", "source": row[0],
                       "message": f"High DNS activity from {row[0]} ({row[1]} queries)", "count": row[1]})

    c.execute("""SELECT src_ip, SUM(length) FROM packets
        GROUP BY src_ip HAVING SUM(length) > 1000000""")
    for row in c.fetchall():
        alerts.append({"type": "large_transfer", "severity": "critical", "source": row[0],
                       "message": f"Large data volume from {row[0]} ({row[1]:,} bytes)", "count": row[1]})

    conn.close()
    return jsonify({"alerts": alerts, "count": len(alerts)})


# ---------------------------
# API - REPORT (CSV download)
# ---------------------------
@app.route("/api/report")
@login_required
def api_report():
    filename = f"report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    filepath = os.path.join(REPORT_FOLDER, filename)

    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT * FROM packets")
    rows = c.fetchall()
    conn.close()

    with open(filepath, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["ID", "Timestamp", "Src IP", "Dst IP",
                         "Protocol", "Src Port", "Dst Port", "Length"])
        writer.writerows(rows)

    log_action(f"{current_user.username} generated report")
    return send_file(filepath, as_attachment=True)


if __name__ == "__main__":
    print("=" * 45)
    print("  NetForensics PCAP Analysis Platform")
    print("  Open http://localhost:5000 in browser")
    print("=" * 45)
    app.run(debug=True, use_reloader=False, threaded=False, port=5000)
