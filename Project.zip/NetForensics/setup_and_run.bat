@echo off
echo ====================================
echo   NetForensics - PCAP Analysis
echo ====================================
echo.

echo [1/3] Installing dependencies...
pip install flask flask-login flask-bcrypt pyshark >nul 2>&1

echo [2/3] Setting up admin account...
python create_admin.py

echo.
echo [3/3] Starting server...
echo.
echo ====================================
echo   Open your browser and go to:
echo   http://localhost:5000
echo.
echo   Username: admin
echo   Password: admin123
echo ====================================
echo.
python app.py
pause
